Aditya Kamleshkumar Patel - 501122872

CPS209 - Assignment 1

My implementation of assignment 1 includes everything that was showcased in the video with no errors or bugs from all my testing.
I have also added the shoes and bonus sorting tasks. I have created 3 new Shoes objects in the products array.
For the sorting tasks, I have implemented it using a mix of Comparable and Comparator interfaces.

This program works bug free and implements all the tasks outlined in the assignment(including BONUS).


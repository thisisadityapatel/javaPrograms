// Name : ADITYA KAMLESHKUMAR PATEL
// Student Number : 501122872
// Email : aditya.patel@ryerson.ca

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;
import java.util.Scanner;
import java.util.Locale.Category;

/*
 * Models a simple ECommerce system. Keeps track of products for sale, registered customers, product orders and
 * orders that have been shipped to a customer
 */
public class ECommerceSystem {
    private ArrayList<Product> products = new ArrayList<Product>();
    private ArrayList<Customer> customers = new ArrayList<Customer>();

    private ArrayList<ProductOrder> orders = new ArrayList<ProductOrder>();
    private ArrayList<ProductOrder> shippedOrders = new ArrayList<ProductOrder>();

    // These variables are used to generate order numbers, customer id's, product
    // id's
    private int orderNumber = 500;
    private int customerId = 900;
    private int productId = 700;

    // General variable used to store an error message when something is invalid
    // (e.g. customer id does not exist)
    String errMsg = null;

    // Random number generator
    Random random = new Random();

    public ECommerceSystem() {
        // NOTE: do not modify or add to these objects!! - the TAs will use for testing
        // If you do the class Shoes bonus, you may add shoe products

        // adding the shoes products
        // products.add(new Shoes("Nike Air Force", generateProductId(), 135.0, 10, 10,
        // 10, 10, 10, 10, 10, 10, 10, 10));
        // products.add(new Shoes("Puma Sliders", generateProductId(), 30.0, 30,
        // Product.Category.SHOES));
        // products.add(new Shoes("Addidas Galaxy", generateProductId(), 250.0, 15,
        // Product.Category.SHOES));

        // Create some products. Notice how generateProductId() method is used
        products.add(new Product("Acer Laptop", generateProductId(), 989.0, 99, Product.Category.COMPUTERS));
        products.add(new Product("Apex Desk", generateProductId(), 1378.0, 12, Product.Category.FURNITURE));
        products.add(
                new Book("Book", generateProductId(), 45.0, 4, 2, "Ahm Gonna Make You Learn", "T. McInerney", 1975));
        products.add(new Product("DadBod Jeans", generateProductId(), 24.0, 50, Product.Category.CLOTHING));
        products.add(new Product("Polo High Socks", generateProductId(), 5.0, 199, Product.Category.CLOTHING));
        products.add(new Product("Tightie Whities", generateProductId(), 15.0, 99, Product.Category.CLOTHING));
        products.add(new Book("Book", generateProductId(), 35.0, 4, 2, "How to Fool Your Prof", "D. Umbast", 1964));
        products.add(
                new Book("Book", generateProductId(), 45.0, 4, 2, "How to Escape from Prison", "A. Fugitive", 1999));
        products.add(new Book("Book", generateProductId(), 44.0, 14, 12, "Ahm Gonna Make You Learn More",
                "T. McInerney", 1945));
        products.add(new Product("Rock Hammer", generateProductId(), 10.0, 22, Product.Category.GENERAL));

        // Adding a multiple pairs of shoes to the products arrayList.
        int[] blackStock = { 120, 120, 120, 120, 120 };
        int[] brownStock = { 120, 120, 120, 120, 120 };
        products.add(new Shoes("Nike Air Jordans 1", generateProductId(), 400.0, blackStock, brownStock));
        products.add(new Shoes("Puma Gravity Freelace", generateProductId(), 112.0, blackStock, brownStock));
        products.add(new Shoes("Sketchers Memoryform", generateProductId(), 164.0, blackStock, brownStock));
        products.add(new Shoes("Adidas NMDs", generateProductId(), 140.0, blackStock, brownStock));
        products.add(new Shoes("Nike Air Force 1", generateProductId(), 220.0, blackStock, brownStock));

        // Create some customers. Notice how generateCustomerId() method is used
        customers.add(new Customer(generateCustomerId(), "Inigo Montoya", "1 SwordMaker Lane, Florin"));
        customers.add(new Customer(generateCustomerId(), "Prince Humperdinck", "The Castle, Florin"));
        customers.add(new Customer(generateCustomerId(), "Andy Dufresne", "Shawshank Prison, Maine"));
        customers.add(new Customer(generateCustomerId(), "Ferris Bueller", "4160 Country Club Drive, Long Beach"));
    }

    private String generateOrderNumber() {
        return "" + orderNumber++;
    }

    private String generateCustomerId() {
        return "" + customerId++;
    }

    private String generateProductId() {
        return "" + productId++;
    }

    public String getErrorMessage() {
        return errMsg;
    }

    public void printAllProducts() {
        for (Product p : products)
            p.print();
    }

    // Print all products that are books. See getCategory() method in class Product
    public void printAllBooks() {
        // Loops through the arraylist product, and then checking if its category is
        // Books,
        // if so. then printing the output.
        for (Product p : products) {
            if (p.getCategory() == Product.Category.BOOKS) {
                p.print();
            }
        }
    }

    // printing all the product that are SHOES.
    public void printAllShoes() {
        // Loops through the arraylist product, and then checking if its category is
        // Shoes,
        // if so. then printing the output.
        for (Product p : products) {
            if (p.getCategory() == Product.Category.SHOES) {
                p.print();
            }
        }
    }

    // Print all current orders
    public void printAllOrders() {
        // Looping through every element in the arraylist orders and then printing it.
        for (ProductOrder o : orders) {
            o.print();
        }
    }

    // Print all shipped orders
    public void printAllShippedOrders() {
        // Looping though every element in the arraylist shippedOrders and then printing
        // it.
        for (ProductOrder o : shippedOrders) {
            o.print();
        }
    }

    // Print all customers
    public void printCustomers() {
        // Looping through every element in the arraylist customers and then printing
        // it.
        for (Customer c : customers) {
            c.print();
        }
    }

    /*
     * Given a customer id, print all the current orders and shipped orders for them
     * (if any)
     */
    public boolean printOrderHistory(String customerId) {
        // Make sure customer exists - check using customerId
        // If customer does not exist, set errMsg String and return false
        // see video for an appropriate error message string
        // ... code here
        boolean flag = false; // flag to keep track if the customer exists (Initially False, assuming that no
                              // customer exists).
        Customer customer = null; // Initialising an object to use it as a refference in case we find the
                                  // customer.
        for (Customer c : customers) { // Looping through each customer in the arraylist
            if (c.getId().equals(customerId)) { // Condition, if we find the right customer by comparing their ID's
                customer = c; // Pointing the object (initialized earlier) to refference this customer.
                flag = true; // Setting flag = true, meaning we found the right customer.
                break; // breaking out of the loop
            }
        }
        if (flag == false) { // if the flag is still false, meaning we did not find the specified customer.
            errMsg = "Customer " + customerId + " Not Found"; // Setting an error message.
            return false; // Returning False;
        }

        // Print current orders of this customer
        System.out.println("Current Orders of Customer " + customerId); // printing all the current orders of the
                                                                        // customer
        // enter code here
        for (ProductOrder o : orders) { // Looping through every order in the ArrayList orders
            if (o.getCustomer().getId().equals(customer.getId())) { // if the order was placed by the same customer, by
                                                                    // comparing their ID's
                o.print(); // Then printing the order using print() function.
            }
        }

        // Print shipped orders of this customer
        System.out.println("\nShipped Orders of Customer " + customerId); // printing the shipped orders of the customer
        // enter code here
        for (ProductOrder o : shippedOrders) { // looping through everyshipped order in the arralist shippedOrders
            if (o.getCustomer().getId().equals(customer.getId())) { // if the order was place by the customer, by
                                                                    // comparing their ID's
                o.print(); // Then printing the shipped order using the print() function.
            }
        }

        return true; // Returning the True since we found the customer.
    }

    public String orderProduct(String productId, String customerId, String productOptions) {
        // First check to see if customer object with customerId exists in array list
        // customers
        // if it does not, set errMsg and return null (see video for appropriate error
        // message string)
        // else get the Customer object
        boolean flag = false;
        Customer customer = null;
        for (Customer c : customers) {
            if (c.getId().equals(customerId)) {
                flag = true;
                customer = c;
                break;
            }
        }
        if (flag == false) {
            errMsg = "Customer " + customerId + " Not Found"; // Setting an error message if the product is not found in
                                                              // the arraylist.
            return null;
        }

        // Check to see if product object with productId exists in array list of
        // products
        // if it does not, set errMsg and return null (see video for appropriate error
        // message string)
        // else get the Product object
        boolean flag2 = false;
        Product product = null;
        for (Product p : products) {
            if (p.getId().equals(productId)) {
                product = p;
                flag2 = true;
                break;
            }
        }
        if (flag2 == false) {
            errMsg = "Product " + productId + " Not Found"; // Setting an error message if the product is not found in
                                                            // the arraylist.
            return null;
        }

        // Check if the options are valid for this product (e.g. Paperback or Hardcover
        // or EBook for Book product)
        // See class Product and class Book for the method vaidOptions()
        // If options are not valid, set errMsg string and return null;
        if (product.getCategory() == Product.Category.BOOKS) {
            if (!product.validOptions(productOptions)) {
                errMsg = "Product " + product.getCategory() + " ProductId " + product.getId() + " Invalid Options: "
                        + productOptions;
                return null;
            }
        }

        // if the category is SHOES then checking if the product option entered is
        // correct or not
        // if the input is not valid then setting the error message accordingly.
        if (product.getCategory() == Product.Category.SHOES) {
            if (!product.validOptions(productOptions)) {
                errMsg = "Product " + product.getCategory() + " ProductId " + product.getId() + " Invalid Options: "
                        + productOptions;
                return null;
            }
        }

        // Check if the product has stock available (i.e. not 0)
        // See class Product and class Book for the method getStockCount()
        // If no stock available, set errMsg string and return null
        if (product.getStockCount(productOptions) == 0) {
            errMsg = "No Stock Available";
            return null;
        }

        // Create a ProductOrder, (make use of generateOrderNumber() method above)
        // reduce stock count of product by 1 (see class Product and class Book)
        // Add to orders list and return order number string
        ProductOrder ord = new ProductOrder(generateOrderNumber(), product, customer, productOptions);
        product.reduceStockCount(productOptions);
        orders.add(ord);
        return ord.getOrderNumber();
    }

    /*
     * Create a new Customer object and add it to the list of customers
     */

    public boolean createCustomer(String name, String address) {
        // Check name parameter to make sure it is not null or ""
        // If it is not a valid name, set errMsg (see video) and return false
        // Repeat this check for address parameter

        // Create a Customer object and add to array list
        if (name.equals("")) {
            errMsg = "Invalid Customer Name";
            return false;
        }
        if (address.equals("")) {
            errMsg = "Invalid Customer Address";
            return false;
        }
        Customer c = new Customer(generateCustomerId(), name, address);
        customers.add(c);
        return true;
    }

    public ProductOrder shipOrder(String orderNumber) {
        // Check if order number exists first. If it doesn't, set errMsg to a message
        // (see video)
        // and return false
        // Retrieve the order from the orders array list, remove it, then add it to the
        // shippedOrders array list
        // return a reference to the order
        boolean flag = false;
        for (ProductOrder o : orders) {
            if (o.getOrderNumber().equals(orderNumber)) {
                flag = true;
                break;
            }
        }
        if (flag == false) {
            errMsg = "Order " + orderNumber + " Not Found";
            return null;
        }
        ProductOrder ans = null;
        for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getOrderNumber().equals(orderNumber)) {
                shippedOrders.add(orders.get(i));
                ans = orders.get(i);
                orders.remove(i);
                break;
            }
        }
        return ans;
    }

    /*
     * Cancel a specific order based on order number
     */
    public boolean cancelOrder(String orderNumber) {
        // Check if order number exists first. If it doesn't, set errMsg to a message
        // (see video)
        // and return false
        boolean flag = false;
        for (int i = 0; i < orders.size(); i++) {
            if (orders.get(i).getOrderNumber().equals(orderNumber)) {
                flag = true;
                orders.remove(i);
                break;
            }
        }
        if (flag == false) {
            errMsg = "Order " + orderNumber + " Not Found";
            return false;
        }
        return true;
    }

    // Sort products by increasing price

    public class CustomComparator1 implements Comparator<Product> {
        @Override
        public int compare(Product p1, Product p2) {
            return Double.compare(p1.getPrice(), p2.getPrice());
        }
    }

    public void sortByPrice() {
        Collections.sort(products, new CustomComparator1());
    }

    // Sort products alphabetically by product name
    public class CustomComparator2 implements Comparator<Product> {
        @Override
        public int compare(Product p1, Product p2) {
            return p1.getName().compareToIgnoreCase(p2.getName());
        }
    }

    public void sortByName() {
        Collections.sort(products, new CustomComparator2());
    }

    // Sort customers alphabetically by customer name
    public class CustomComparator3 implements Comparator<Customer> {
        @Override
        public int compare(Customer p1, Customer p2) {
            return p1.getName().compareToIgnoreCase(p2.getName());
        }
    }

    public void sortCustomersByName() {
        Collections.sort(customers, new CustomComparator3());
    }

    // BONUS PROGRAM PART - Returning the books by a particular author in Sorted
    // Order(on basis of year published).
    // Making the function method SEARCHBYAUTHOR.

    // Class CustomComparator4 that implements the interface Comparator to sort the
    // book for a specific author
    // on basis of the date they were published at.
    public class CustomComparator4 implements Comparator<Product> {
        @Override
        public int compare(Product p1, Product p2) {
            return Integer.compare(p1.getBookYear(), p2.getBookYear());
        }
    }

    public boolean searchbyauthor(String author) {
        ArrayList<Product> temp = new ArrayList<Product>();
        for (Product p : products) {
            if (p.getCategory() == Product.Category.BOOKS) {
                temp.add(p);
            }
        }
        // sorting the product books that were in arralist temp
        Collections.sort(temp, new CustomComparator4());

        for (Product b : temp) {
            if (b.getAuthorName().equalsIgnoreCase(author)) {
                b.print();
            }
        }
        return true;
    }
}
